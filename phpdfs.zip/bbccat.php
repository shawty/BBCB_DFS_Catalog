<link href="styles.css" rel="stylesheet" type="text/css"> <?php

function bbccat($thisdisk)
{

  $diskname = "";             // Default used variables
  $files    = array();
  $dirs     = array();
  $sequence = 0;
  $catcount = 0;
  $sectors  = 0;
  $bootopt  = 0;
  $loadaddr = array();
  $execaddr = array();
  $fileleng = array();
  $diskaddr = array();

  $infile = fopen($thisdisk,"rb"); // Open binary disk image
  if($infile)
  {
    $diskname = fread($infile,8); // Get first 8 chars of disk name
    
    for($count=0;$count<31;$count++)
    {
      $files[$count] = fread($infile,7); // Get each file name
      $dirs[$count]  = fread($infile,1); // Get directory specifier
    }
    
    $diskname = $diskname.fread($infile,4); // Last 4 chars of title
    
    $sequence = ord(fread($infile,1)); // Get disk writes
    
    $catcount = ord(fread($infile,1))/8; // Get num of catalouge entries
    
    $temp = ord(fread($infile,1));
    
    $sectors = (($temp & 3)<<8); //+
    $sectors = $sectors + ord(fread($infile,1)); // Get number of disk sectors
    
    $bootopt = ($temp & 12)>>2; // Get boot option
    
    for($count=0;$count<31;$count++) // get file lengths and addresses
    {
      $loadaddr[$count] = ord(fread($infile,1))+( ord(fread($infile,1)) << 8 );
      $execaddr[$count] = ord(fread($infile,1))+( ord(fread($infile,1)) << 8 );
      $fileleng[$count] = ord(fread($infile,1))+( ord(fread($infile,1)) << 8 );
      
      $temp = ord(fread($infile,1));
      
      $loadaddr[$count] = $loadaddr[$count] + ( ($temp & 12)  << 14 );
      $execaddr[$count] = $execaddr[$count] + ( ($temp & 192) << 10 );
      $fileleng[$count] = $fileleng[$count] + ( ($temp & 48)  << 12 );
      
      $diskaddr[$count] = ord(fread($infile,1)) + (($temp & 3) << 8);
            
    }
    
    fclose($infile); // Close binary disk file
    
    // From here on we print the output.............
     
    print "<table ID=cattable border=0 cell spacing=1 cellpadding = 2>\n";
    print "<tr><th>Disk Title</th><td colspan=5>".trim($diskname)."</td></tr>";
    print "<tr><th>Sequence</th><td colspan=5>".$sequence."</td></tr>";
    print "<tr><th>Cat Entries</th><td colspan=5>".$catcount."</td></tr>";
    print "<tr><th>Sectors</th><td colspan=5>".$sectors."</td></tr>";
    print "<tr><th>Boot Option</th><td colspan=5>".$bootopt."</td></tr>";
    
    print "<tr>";
    print "<th>Dir</th>";
    print "<th>File</th>";
    print "<th>Load</th>";
    print "<th>Exec</th>";
    print "<th>Length</th>";
    print "<th>Disk Addr</th>";
    print "</tr>\n";
    
    for($count=0;$count<$catcount;$count++)
    {
      
      $filename = trim($files[$count]);
      $dirname  = trim($dirs[$count]);

      print "<tr>\n";
      print "<td>".$dirname."</td>";
            
      $desturl = "extractfile.php?dir=".$dirname."&disk=".$thisdisk."&file=".$filename."&start=".$diskaddr[$count]."&length=".$fileleng[$count];
      
      print "<td><a href='".$desturl."' title='Click to save file.'>".$filename."</td>";
      
      print "<td>".sprintf("%06X",$loadaddr[$count])."</td>";
      print "<td>".sprintf("%06X",$execaddr[$count])."</td>";
      print "<td>".sprintf("%06X",$fileleng[$count])."</td>";
      print "<td>".sprintf("%06X",$diskaddr[$count])."</td>";
      print "</tr>\n";
      
    }
    
    print "</table>";

    
  }
  else
  {
    print "Could not open Disk file to display catalouge.";
  }
  
}
 
?>