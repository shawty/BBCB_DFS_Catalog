<?php

  include_once("bbccat.php");  // Include the BBCCAT procedure
  
?>

<html>

<head>
  <title>Catalouge of a BBC Single sided disk.</title>
  <link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>

  <h1>Demo of bbccat.php by shawty</h1>

  <?php
    bbccat("test1.ssd"); // Make use of it :-)
  ?>
  
</body>

</html>