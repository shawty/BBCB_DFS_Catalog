<?php

  // BBC Disk File sender...
  // Usage is ..
  //
  // extractfile.php?dir=<D>&disk=<BBCDISK>&file=<FILENAME>&start=<SECTORSTART>&length=<FILELENGTH>
  //
  // <D>           = Directory identifier (Used for naming the final file to save
  // <BBCDISK>     = Name of the BBC Disk file image
  // <FILENAME>    = Name of file to extract, only used for saving file, not for lookup
  // <SECTORSTART> = Sector start address divided by 256 (As entered in BBC Disk Catalouge)
  // <FILELENGTH>  = Actual length of file data in bytes

  $dir    = $_GET['dir'];
  $disk   = $_GET['disk'];
  $file   = $_GET['file'];
  $start  = $_GET['start'];
  $length = $_GET['length'];

  $savename = $dir."_".$file; // This will create files like 'D_FILE' EG '$_FILE1'

  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");                      // some day in the past stops the browser...
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");         // ...trying to cache the file
  header("Content-type: application/x-download");                        // Browser header to make save (Can spec mime type here if wish)           
  header("Content-Disposition: attachment; filename=".$savename);        // Provide file name's etc to dloader
  header("Content-Transfer-Encoding: binary");                           // Set the encoding..
  header("Content-length: ".$length);                                    // Set the file length to save

  $infile = fopen($disk,"rb");        // Open disk image for bianry read
  
  $offset = $start * 256;             // Get actual file offset
  fseek($infile,$offset);             // and move file pointer to that position
  
  $contents = fread($infile,$length); // Read whole file into a PHP Variable
  
  print $contents;                    // And send them to the browser
  
  fclose($infile);                    // and finaly close the input file
  
?>